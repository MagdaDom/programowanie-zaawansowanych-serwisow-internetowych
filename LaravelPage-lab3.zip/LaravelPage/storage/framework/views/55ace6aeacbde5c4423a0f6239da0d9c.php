

<?php $__env->startSection('content'); ?>

Hello world!

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\php_websites\phpadvanced\LaravelPage\resources\views/home/index.blade.php ENDPATH**/ ?>