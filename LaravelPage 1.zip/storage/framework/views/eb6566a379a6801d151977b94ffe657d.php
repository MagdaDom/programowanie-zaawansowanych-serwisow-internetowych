

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-12">
            <a href="/internal-events">Wydarzenia wewnętrzne</a>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\local\Downloads\1514718_1248009_app\resources\views/home/index.blade.php ENDPATH**/ ?>