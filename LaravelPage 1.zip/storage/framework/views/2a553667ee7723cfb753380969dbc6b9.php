<div>
    Początek widoku
</div>

<?php echo $__env->yieldContent('content'); ?>

<div>
    Koniec widoku
</div><?php /**PATH C:\Users\local\Downloads\1514718_1248009_app\resources\views/main.blade.php ENDPATH**/ ?>