<div>
    Początek widoku
</div>

<?php echo $__env->yieldContent('content'); ?>

<div>
    Koniec widoku
</div><?php /**PATH C:\xampp\htdocs\php_websites\phpadvanced\LaravelPage\resources\views/main.blade.php ENDPATH**/ ?>