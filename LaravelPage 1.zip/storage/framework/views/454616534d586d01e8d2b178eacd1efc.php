<div>
    Początek widoku
</div>

<?php echo $__env->yieldContent('content'); ?>

<div>
    Koniec widoku
</div><?php /**PATH C:\xampp\htdocs\SerwisyLabLaravel\resources\views/main.blade.php ENDPATH**/ ?>